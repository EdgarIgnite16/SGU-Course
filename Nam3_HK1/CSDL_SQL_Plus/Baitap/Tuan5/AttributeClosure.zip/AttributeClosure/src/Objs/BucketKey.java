package Objs;

import java.util.HashSet;

public class BucketKey {
    public HashSet<Character> bucket;

    public BucketKey(HashSet<Character> bucket){
        this.bucket = bucket;
    }


}
